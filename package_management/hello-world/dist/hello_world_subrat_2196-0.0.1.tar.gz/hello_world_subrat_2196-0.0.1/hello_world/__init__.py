from .main import add 
# during import of package only we will get add also