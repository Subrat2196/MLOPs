hello_world
    - hello_world
        - __init__.py
        - main.py

# Virtual Environment 
```
python -m venv hello_demo  
.\hello_demo\Scripts\Activate
pip install setuptools twine
python setup.py sdist

```