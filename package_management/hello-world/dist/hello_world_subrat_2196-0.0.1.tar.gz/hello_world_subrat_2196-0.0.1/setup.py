from setuptools import setup, find_packages

setup(
    name="hello_world_subrat_2196",
    version="0.0.1",
    author="Subrat Bahuguna",
    author_email="subrat2196@gmail.com",
    description="hello world example package",
    packages=find_packages(), # automatically discover python packages within the project directory
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: IIIT Bangalore",
    ],
)